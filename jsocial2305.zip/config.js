'use strict'

module.exports = {
    mailer: {
        service: 'Gmail',
        auth: {
            user: 'manuel.adele@gmail.com',
            pass: 'Jean_3:16'
        }
    },
    dbConnstring: 'mongodb://p4cm4n972:made81MA@ds111461.mlab.com:11461/proze',
    sessionKey: 'WelcomToGalajsy',
    facebook: {
        clientID: '288860251564912',
        clientSecret: '6efb5cd8ce74993b286eac5bdc2f4c33'
    },
    TWITTER_KEY: 'bETJ89puTYN418qTGFvyXseJN',
    TWITTER_SECRET: 'mHe1cHOEnyDb2zwvMWW6scj7qlcdoAurWOUvdqgvk2nS01xZYS',
    INSTAGRAM_ID: '021ff5e380ef4f619129d392690861ca',
    INSTAGRAM_SECRET: 'd86cfe18cc0a49fc852f8198b69773cd'
}